package assignment07;

public class Point {

    private int r, c, d;

    public Point(int r, int c, int d){
        this.r = r;
        this.c = c;
        this.d = d;
    }
    int row, col, dist;
}
